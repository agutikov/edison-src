


extern int foo;

int getfoo() { return foo; }


extern int other;

int getother() { return other; }

