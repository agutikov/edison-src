
int aData = 0;

void a()
{
	++aData;
}
