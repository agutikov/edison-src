

int __attribute__((visibility("hidden"))) data = 3;

void __attribute__((visibility("hidden"))) func(int x) { }



