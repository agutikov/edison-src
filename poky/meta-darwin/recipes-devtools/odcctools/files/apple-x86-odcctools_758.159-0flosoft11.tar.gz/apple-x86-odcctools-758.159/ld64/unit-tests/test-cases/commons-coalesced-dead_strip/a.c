#include "c.h"

float aa() { return bar; }

