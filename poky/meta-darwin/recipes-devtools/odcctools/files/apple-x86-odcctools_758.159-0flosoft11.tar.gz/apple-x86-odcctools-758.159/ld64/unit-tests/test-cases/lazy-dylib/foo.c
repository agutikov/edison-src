
int data = 5;

int foo() { return 1; }
int bar() { return 1; }
