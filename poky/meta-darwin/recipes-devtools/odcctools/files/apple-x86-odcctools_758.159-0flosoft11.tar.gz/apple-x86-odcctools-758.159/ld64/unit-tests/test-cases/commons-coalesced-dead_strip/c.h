
// missing extern
const float bar;

