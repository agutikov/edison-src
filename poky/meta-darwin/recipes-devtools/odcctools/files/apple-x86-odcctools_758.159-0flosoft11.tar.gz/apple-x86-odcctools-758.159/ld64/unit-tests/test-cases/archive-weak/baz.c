


// intentionally not-weak
int baz() 
{ 
	return 1; 
}



