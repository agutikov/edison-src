#include <stdio.h>


void foo()
{
	fprintf(stdout, "foo\n");
}

