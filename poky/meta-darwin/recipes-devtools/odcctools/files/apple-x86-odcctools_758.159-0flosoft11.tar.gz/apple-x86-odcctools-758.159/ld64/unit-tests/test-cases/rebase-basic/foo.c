
int foo() { return 10; }

void* foop = &foo;

int glob = 5;

int* globp = &glob;


int big[3000];


 