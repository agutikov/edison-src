extern int foo();
extern int bar();
extern int wrap();

int main()
{
   foo();
   bar();
   wrap();
  return 0;
}
