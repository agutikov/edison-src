

#include "bar.h"

void bar1() {}
void bar2() {}
void bar3() {}
void bar4() {}

