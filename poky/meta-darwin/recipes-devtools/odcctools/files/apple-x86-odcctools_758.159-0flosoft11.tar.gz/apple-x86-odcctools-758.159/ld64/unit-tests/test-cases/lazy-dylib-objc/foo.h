
#include <Foundation/Foundation.h>


@interface Foo : NSObject



@end
