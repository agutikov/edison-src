#if HAVE_CONFIG_H
#include <config.h>
#endif

const char apple_version[]= PACKAGE_NAME "-" PACKAGE_VERSION;
const char ldVersionString[]= "@(#)PROGRAM:ld  PROJECT:" PACKAGE_NAME "-" PACKAGE_VERSION "\n";
